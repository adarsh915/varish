<?php include 'include/header.php'; ?>
<title>BigwayStudio - Archive</title>

<div class="vm-filter-links container-fluid side-gap mt-5">
<h1 class="">Archive©11-24</h1>
</div>
<!-- <div class="container-fluid image-grid side-gap mt-5">
    <h1 class="">Archive©11-24</h1>
</div> -->
<div class="container-fluid image-grid side-gap">
  <div class="row">
    
    <!-- Column 1 -->
    <div class="col-md-4 d-flex flex-column">
      <div class="img-box h-large">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
      <div class="img-box h-medium">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
      <div class="img-box h-large">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
       <div class="img-box h-medium">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
    </div>

    <!-- Column 2 -->
    <div class="col-md-4 d-flex flex-column">
      <div class="img-box h-medium">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
      <div class="img-box h-large">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
      <div class="img-box h-medium">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
       <div class="img-box h-large">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
    </div>

    <!-- Column 3 -->
     <div class="col-md-4 d-flex flex-column">
      <div class="img-box h-large">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
      <div class="img-box h-medium">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
      <div class="img-box h-large">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
       <div class="img-box h-medium">
        <img src="assets/images/9-7-scaled.jpg" alt="">
      </div>
    </div>

  </div>
</div>

<?php include 'include/footer.php'; ?>