<?php include 'include/header.php'; ?>
<title>BigwayStudio - Artical</title>
<div class="vm-filter-links container-fluid side-gap mt-5">
  <a href="#" class="vm-filter-link active text-dark"><h1>Recents,</h1></a>
  <a href="#" class="vm-filter-link"><h1>Design,</h1></a>
  <a href="#" class="vm-filter-link"><h1>Development,</h1></a>
  <a href="#" class="vm-filter-link"><h1>Management,</h1></a>
  <a href="#" class="vm-filter-link"><h1>Marketing</h1></a>
</div>
<!-- <div class="container-fluid image-grid side-gap">
  <div class="row g-4">
   
    <div class="col-md-4">
      <div class="h-100 d-flex ">
        <div >
          <h5 class="fw-bold mb-2">Hello world!</h5>
          <a href="#" class="text-decoration-none">READ MORE</a>
        </div>
      </div>
    </div>
  

   
    <div class="col-md-4">
      <div class="position-relative overflow-hidden">
        <img
          src="assets/image2/a-1.jpg"
          alt="Card 1"
          class="tile-img"
        />
        <div class="tile-overlay pt-3 pb-4">
          <h5>We made it to the club</h5>
          <a href="#">READ MORE</a>
        </div>
      </div>
    </div>

    
    <div class="col-md-4">
      <div class="position-relative overflow-hidden">
        <img
          src="assets/image2/a-2.jpg"
          alt="Card 2"
          class="tile-img"
        />
        <div class="tile-overlay pt-3 pb-4">
          <h5>I was born a very grumpy baby</h5>
          <a href="#">READ MORE</a>
        </div>
        </div>
    </div>
	   </div>

       <div class="row g-4">
    
       <div class="col-md-4">
      <div class="position-relative overflow-hidden">
        <img
          src="assets/image2/a-3.jpg"
          alt="Card 1"
          class="tile-img"
        />
        <div class="tile-overlay pt-3 pb-4">
          <h5>We made it to the club</h5>
          <a href="#">READ MORE</a>
        </div>
      </div>
    </div>


    <div class="col-md-4">
      <div class="position-relative overflow-hidden">
        <img
          src="assets/image2/a-4.jpg"
          alt="Card 1"
          class="tile-img"
        />
        <div class="tile-overlay pt-3 pb-4">
          <h5>We made it to the club</h5>
          <a href="#">READ MORE</a>
        </div>
      </div>
    </div>

  
    <div class="col-md-4">
      <div class="position-relative overflow-hidden">
        <img
          src="assets/image2/a-5.jpg"
          alt="Card 2"
          class="tile-img"
        />
        <div class="tile-overlay pt-3 pb-4">
          <h5>I was born a very grumpy baby</h5>
          <a href="#">READ MORE</a>
        </div>
        </div>
    </div>
	   </div>


     
       <div class="row g-4">
   
       <div class="col-md-4">
      <div class="position-relative overflow-hidden">
        <img
          src="assets/image2/a-6.jpg"
          alt="Card 1"
          class="tile-img"
        />
        <div class="tile-overlay pt-3 pb-4">
          <h5>We made it to the club</h5>
          <a href="#">READ MORE</a>
        </div>
      </div>
    </div>

 
    <div class="col-md-4">
      <div class="position-relative overflow-hidden">
        <img
          src="assets/image2/a-7.jpg"
          alt="Card 1"
          class="tile-img"
        />
        <div class="tile-overlay pt-3 pb-4">
          <h5>We made it to the club</h5>
          <a href="#">READ MORE</a>
        </div>
      </div>
    </div>

    
    <div class="col-md-4">
      <div class="position-relative overflow-hidden">
        <img
          src="assets/image2/a-8.jpg"
          alt="Card 2"
          class="tile-img"
        />
        <div class="tile-overlay pt-3 pb-4">
          <h5>I was born a very grumpy baby</h5>
          <a href="#">READ MORE</a>
        </div>
        </div>
    </div>
	   </div>
</div> -->



<div class="container-fluid side-gap image-grid">
    <div class="row g-4">
     <div class="col-md-4 col-lg-6">
        <div class="project-card selected-project">
          <img src="assets/image2/a-1.jpg" class="project-image" alt="Project 1">
          <div class="project-info">
          <h3 class="project-title">I was born a very grumpy baby</h3>
           <a href="#"><p class="project-category">READ MORE</p></a>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-6">
        <div class="project-card selected-project">
          <img src="assets/image2/a-2.jpg" class="project-image" alt="Project 1">
          <div class="project-info">
          <h3 class="project-title">I was born a very grumpy baby</h3>
            <a href="#"><p class="project-category">READ MORE</p></a>
          </div>
        </div>
      </div>
            <div class="col-md-4 col-lg-6">
        <div class="project-card">
          <img src="assets/image2/a-3.jpg" class="project-image" alt="Project 3">
          <div class="project-info">
            <h3 class="project-title">We made it to the club</h3>
            <a href="#"><p class="project-category">READ MORE</p></a>
          </div>
        </div>
      </div>

       <div class="col-md-4 col-lg-6">
        <div class="project-card">
          <img src="assets/image2/a-4.jpg" class="project-image" alt="Project 3">
          <div class="project-info">
             <h3 class="project-title">We made it to the club</h3>
            <a href="#"><p class="project-category">READ MORE</p></a>
          </div>
        </div>
      </div>

       <div class="col-md-4 col-lg-6">
        <div class="project-card">
          <img src="assets/image2/a-5.jpg" class="project-image" alt="Project 3">
          <div class="project-info">
            <h3 class="project-title">I was born a very grumpy baby</h3>
            <a href="#"><p class="project-category">READ MORE</p></a>
          </div>
        </div>
      </div>


       <div class="col-md-4 col-lg-6">
        <div class="project-card">
          <img src="assets/image2/a-6.jpg" class="project-image" alt="Project 3">
          <div class="project-info">
           <h3 class="project-title">We made it to the club</h3>
            <a href="#"><p class="project-category">READ MORE</p></a>
          </div>
        </div>
      </div>
   
      
       <div class="col-md-4 col-lg-6">
        <div class="project-card">
          <img src="assets/image2/a-7.jpg" class="project-image" alt="Project 3">
          <div class="project-info">
            <h3 class="project-title">We made it to the club</h3>
            <a href="#"><p class="project-category">READ MORE</p></a>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-6">
        <div class="project-card">
          <img src="assets/image2/a-8.jpg" class="project-image" alt="Project 3">
          <div class="project-info">
            <h3 class="project-title">We made it to the clubI was born a very grumpy baby</h3>
            <a href="#"><p class="project-category">READ MORE</p></a>
          </div>
        </div>
      </div>
    




    </div>
</div>


<?php include 'include/footer.php';  ?>